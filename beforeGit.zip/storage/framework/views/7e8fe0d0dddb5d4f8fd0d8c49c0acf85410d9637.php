<?php $__env->startSection('content'); ?>

<div class="box">
    <div class="box-header">
      <h3 class="box-title"><?php echo e($title); ?></h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <?php echo Form::open(['route' => ['clients.update', $client->id], 'method' => 'put']); ?>

            <div class="form-group">
                <?php echo Form::label('name', trans('admin.name')); ?>

                <?php echo Form::text('name', $client->name,['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('gender', trans('admin.gender')); ?>

                <?php echo Form::select('gender', ['male'=>trans('admin.male'), 'female'=>trans('admin.female'), 'other'=>trans('admin.other')], $client->gender,['class'=>'form-control', 'placeholder'=>'Choose Gender']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('age', trans('admin.age')); ?>

                <?php echo Form::number('age', $client->age,['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('country', trans('admin.country')); ?>

                <?php echo Form::text('country', $client->country,['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('fb', trans('admin.fb')); ?>

                <?php echo Form::text('fb', $client->fb,['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('phone', trans('admin.phone')); ?>

                <?php echo Form::number('phone', $client->phone,['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('email', trans('admin.email')); ?>

                <?php echo Form::email('email', $client->email,['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('preflang', trans('admin.preflang')); ?>

                <?php echo Form::text('preflang', $client->preflang,['class'=>'form-control']); ?>

            </div>
            <div class="form-group" id='df_call'>
                <?php echo Form::label('f_call', trans('admin.if_fail_call')); ?>

                <label for="f_call" class="btn btn-danger">
                    <?php echo Form::checkbox('f_call', 1);; ?>

                </label>
            </div>
            <div id="d_statu">
                <div class="form-group">
                    <?php echo Form::label('statu', trans('admin.statu')); ?>

                    <?php echo Form::select('statu', ['0'=>trans('admin.new'), '1'=>trans('admin.process'), '2'=>trans('admin.atten'), '3'=>trans('admin.finished_fail'), '4'=>trans('admin.finished_succ')], $client->statu,['class'=>'form-control',
                'placeholder'=>'Choose Statu']); ?>

                </div>
                <div class="form-group">
                    <?php if($client->statu == 0): ?>
                    <a href="javascript:;" onclick='start_conv()' class='btn btn-primary'>Start conversation</a>
                    <?php elseif($client->statu == 1): ?>
                    <a href="javascript:;" onclick='end_convs()' class='btn btn-success'>successful conversation</a>
                    <a href="javascript:;" onclick='end_convf()' class='btn btn-danger'>failed conversation</a>
                    <a href="javascript:;" onclick='need_atten()' class='btn btn-warning'>Needs Attention</a>
                    <?php elseif($client->statu == 2): ?>
                    <a href="javascript:;" onclick='start_soul()' class='btn btn-warning'>Start Dealing</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group" id='try_note' style='display:none'>
                <?php echo Form::textarea('try_note', '',['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('notes', trans('admin.notes')); ?>

                <?php echo Form::textarea('notes', $client->notes,['class'=>'form-control']); ?>

            </div>

            <div class="panel panel-primary">
                <div class="panel-heading"><h4>Older Tries</h4></div>
                <div class="panel-body">
                    <div class="panel panel-default">
                        <div class="panel-heading">Older Tries</div>
                        <div class="panel-body">
                        Panel content
                        </div>
                        <div class="panel-body">
                        Panel content
                        </div>
                    </div>
                </div>
            </div>
            <?php echo Form::submit('Submit'); ?>

        <?php echo Form::close(); ?>


    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>