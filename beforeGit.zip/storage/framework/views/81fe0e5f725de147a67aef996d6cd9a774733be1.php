<?php $__env->startSection('content'); ?>

<div class="box">
    <div class="box-header">
      <h3 class="box-title"><?php echo e($title); ?></h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <?php echo Form::open(['url' => aurl('clients')]); ?>

            <div class="form-group">
                <?php echo Form::label('name', trans('admin.name')); ?>

                <?php echo Form::text('name', old('name'),['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('gender', trans('admin.gender')); ?>

                <?php echo Form::select('gender', ['male'=>trans('admin.male'), 'female'=>trans('admin.female'), 'other'=>trans('admin.other')], old('gender'),['class'=>'form-control',
            'placeholder'=>'Choose Gender']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('age', trans('admin.age')); ?>

                <?php echo Form::number('age', old('age'),['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('country', trans('admin.country')); ?>

                <?php echo Form::text('country', old('country'),['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('fb', trans('admin.fb')); ?>

                <?php echo Form::text('fb', old('fb'),['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('phone', trans('admin.phone')); ?>

                <?php echo Form::number('phone', old('phone'),['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('email', trans('admin.email')); ?>

                <?php echo Form::email('email', old('email'),['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('preflang', trans('admin.preflang')); ?>

                <?php echo Form::text('preflang', old('preflang'),['class'=>'form-control']); ?>

            </div>
            <?php echo Form::submit('Submit'); ?>

        <?php echo Form::close(); ?>


    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>