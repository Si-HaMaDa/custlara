<?php $__env->startSection('content'); ?>

<div class="box">
    <div class="box-header">
      <h3 class="box-title"><?php echo e($title); ?></h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <?php echo $dataTable->table(['class'=>'dataTable table table-striped table-hover  table-bordered'],true); ?>

    </div>
    <!-- /.box-body -->
</div>
<!-- /.box -->

<?php $__env->startPush('js'); ?>
<?php echo $dataTable->scripts(); ?>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>