<?php if(count($errors->all()) > 0): ?>
    <div class="alert-danger alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
    <div class="alert-success alert">
        <h3><?php echo e(session('success')); ?></h3>
    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert-danger alert">
        <h3><?php echo e(session('error')); ?></h3>
    </div>
<?php endif; ?>